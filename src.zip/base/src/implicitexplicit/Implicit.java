package implicitexplicit;

public class Implicit {
	int a=10;
	long b=a;

}
