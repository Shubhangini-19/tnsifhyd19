package implicitexplicit;

public class Explicit {
	long c=20;
	int d= (int)c;
	
}
