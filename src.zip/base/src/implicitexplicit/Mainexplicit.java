package implicitexplicit;

public class Mainexplicit {
	public static void main(String[] args) {
	Explicit e=new Explicit();
	System.out.println(e.d);
	System.out.println(e.c);
}
}