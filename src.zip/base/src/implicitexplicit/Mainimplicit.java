package implicitexplicit;

public class Mainimplicit {
	public static void main(String[] args) {
		Implicit i=new Implicit();
		System.out.println(i.a);
		System.out.println(i.b);
	}
}
