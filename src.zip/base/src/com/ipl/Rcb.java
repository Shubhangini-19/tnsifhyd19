package com.ipl;

public class Rcb {
	void batsman()
	{
		System.out.println("virat");
	}
	void bowler() {
		System.out.println("siraj");
	}
}
