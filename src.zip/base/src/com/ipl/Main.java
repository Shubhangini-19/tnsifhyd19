package com.ipl;

public class Main {
	public static void main(String[] args) {
		Rcb r = new Rcb();
		r.batsman();
		r.bowler();
		Csk c=new Csk();
		c.batsman();
		c.bowler();
		Srh s=new Srh();
		s.batsman();
		s.bowler();
				
	}

}
