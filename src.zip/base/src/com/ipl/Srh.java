package com.ipl;

public class Srh {
	void batsman() {
		System.out.println("head");
	}
	void bowler() {
		System.out.println("pat");
	}

}
