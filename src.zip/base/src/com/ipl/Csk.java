package com.ipl;

public class Csk {
	void batsman()
	{
		System.out.println("dhoni");
	}
	void bowler() {
		System.out.println("pathrana");
	}
}
