package com.inheritance;

public class HeirarichalB extends Heirarichal{
	public void print() {
		System.out.println("I am a method from class B");
	}

}
