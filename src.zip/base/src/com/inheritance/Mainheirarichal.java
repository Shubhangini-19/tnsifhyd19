package com.inheritance;

public class Mainheirarichal {
	public static void main(String[] args) {

	HeirarichalA a=new HeirarichalA();
	HeirarichalB b=new HeirarichalB();
		a.display();
		b.display();
		
	
	}
}
