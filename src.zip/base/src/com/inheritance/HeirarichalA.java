package com.inheritance;

public class HeirarichalA extends Heirarichal {
	public void print() {
		System.out.println("I am a method from class A");
	}

}


