package com.inheritance;

public class Protected {
	public class AnimalProtected {
		
		protected String name;

		  protected void display() {
		    System.out.println("I am an animal.");
		  }
}
}