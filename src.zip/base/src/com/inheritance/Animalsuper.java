package com.inheritance;

public class Animalsuper {
	public void eat() {
		System.out.println("i can eat");
	}
	
}
