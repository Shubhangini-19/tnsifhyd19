package com.inheritance;

public class Heirarichal {
		
		public void display() {
			System.out.println("I am method from class A");
		}
}

