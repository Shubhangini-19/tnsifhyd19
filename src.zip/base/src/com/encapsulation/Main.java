package com.encapsulation;

public class Main {
		public static void main(String[] args) {
			
			Exam1 e1 = new Exam1();
			e1.setPen("blue");
			e1.setFootware("outside");
			e1.setHallticket("yes");
			
			System.out.println(e1.getPen());
			System.out.println(e1.getFootware());
			System.out.println(e1.getHallticket());
		}
	}

