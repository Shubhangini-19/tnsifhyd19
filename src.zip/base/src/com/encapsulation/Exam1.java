package com.encapsulation;

public class Exam1 {
	private String pen;
	private String footware;
	public String hallticket;
	public String getPen() {
		return pen;
	}
	public void setPen(String pen) {
		this.pen = pen;
	}
	public String getFootware() {
		return footware;
	}
	public void setFootware(String footware) {
		this.footware = footware;
	}
	public String getHallticket() {
		return hallticket;
	}
	public void setHallticket(String hallticket) {
		this.hallticket = hallticket;
	}
}
