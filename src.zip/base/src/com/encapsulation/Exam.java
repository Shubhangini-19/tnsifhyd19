package com.encapsulation;

public class Exam {
	private String pen;
	private String footware;
	public String hallticket;